#!/bin/bash
set -e

###################################################################
# Disable network interface name changing
# sudo nano /etc/default/grub
# GRUB_CMDLINE_LINUX="net.ifnames=0 biosdevname=0"
# sudo grub-mkconfig -o /boot/grub/grub.cfg
# 
# !!! sửa lại cấu hình IP theo tên interface mới
# Update new netplan config
# cp systemd/50-cloud-init.yaml /etc/netplan/50-cloud-init.yaml
# netplan apply
#
# sudo reboot
####################################################################

echo "=====================Setup script for ngproxy v1.5====================="

echo "=====================Update, upgrade require pakages====================="
rm -f /etc/machine-id
rm -f /var/lib/dbus/machine-id
dbus-uuidgen --ensure=/etc/machine-id
dbus-uuidgen --ensure
apt-get update
#apt-get -y upgrade
apt-get install -y python python-dev python-pip wvdial ppp usb-modeswitch squid socat apache2-utils
pip install -r requirements.txt

echo "=====================Installing====================="
# disable IPv6 and modify dhcp config
#cp systemd/99-sysctl.conf /etc/sysctl.d/99-sysctl.conf
#sysctl -p
cp systemd/dhclient.conf /etc/dhcp/dhclient.conf
cp systemd/nodnsupdate /etc/dhcp/dhclient-enter-hooks.d/nodnsupdate
chmod +x /etc/dhcp/dhclient-enter-hooks.d/nodnsupdate

if [ -e /etc/dhcp/dhclient-enter-hooks.d/resolved ]; then
  rm /etc/dhcp/dhclient-enter-hooks.d/resolved
fi
if [ -e /etc/dhcp/dhclient-enter-hooks.d/resolvconf ]; then
  rm /etc/dhcp/dhclient-enter-hooks.d/resolvconf
fi

# ppp
systemctl disable pppd-dns.service
rm -R /etc/ppp/ip-up.d/
rm -R /etc/ppp/ip-down.d/
cp -R ppp/ip-up.d/ /etc/ppp/
cp -R ppp/ip-down.d/ /etc/ppp/
cp -R ppp/peers/ /etc/ppp/
chmod -R +x /etc/ppp/ip-up.d/
chmod -R +x /etc/ppp/ip-down.d/

# squid
cp squid/squid.conf /etc/squid/
echo "p5R1z9U9WcfEeusA" | htpasswd -i -c /etc/squid/passwd ngproxy
cp squid/squid.service /lib/systemd/system/
systemctl daemon-reload
systemctl enable ngproxy.service
systemctl restart squid.service

# ngproxy
cpu_arch=$(python -c "import platform; print(platform.processor());")
cp -R ngproxy/"$cpu_arch" /etc/ngproxy
cp systemd/ngproxy.service /lib/systemd/system/
systemctl daemon-reload
systemctl enable ngproxy.service
systemctl start ngproxy.service

echo "Install completed!"
