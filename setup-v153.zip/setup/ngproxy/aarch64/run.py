#!/usr/bin/env python
# -*- coding: utf-8 -*-

import argparse
import os
import sys

sys.path.append(os.path.dirname(os.path.dirname(os.path.realpath(__file__))))

try:
    from main import debug, main
except ImportError as e:
    print(str(e))
    sys.exit(1)

if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description='NGProxy - NextGen Proxy')
    parser.add_argument(
        '--debug', help='Debug device and get information', action='store_true')
    args = parser.parse_args()

    if args.debug:
        debug()
        sys.exit(0)

    main()
